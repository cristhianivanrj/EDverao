#include <stdio.h>
#include <stdlib.h>
#include "lista01.h"

int main(int argc, char* argv[])
{

FormatoLst * argLista = (FormatoLst *)malloc(sizeof(FormatoLst));
insereInicio(5,argLista);
insereFinal(1,argLista);
insereFinal(5,argLista);
insereFinal(15,argLista);
imprimeLista(argLista);
inserir(1,30,argLista);
imprimeLista(argLista);
printf("Busca pelo 30: %d\n",busca1(30,argLista));
imprimeLista(argLista);
printf("Numero removido pos 2: %d\n",remover(2,argLista));
imprimeLista(argLista);
printf("IndFimLstLst!!!\n");
}
