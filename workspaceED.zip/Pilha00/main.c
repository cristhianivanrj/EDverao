#include <stdio.h>
#include <stdlib.h>
#include "pilha00.h"

int main (int argc, char *argv[]){
    /*FormatoLst * l = (FormatoLst *)malloc(sizeof(FormatoLst));
    insereFinal(1,l);
    insereFinal(2,l);
    insereFinal(3,l);
    inserir(2,30,l);
    //printf("Numero removido pos 2: %d\n",remover(2,l));

    while(!estaVazia(l)){
       int rmv = removeIndIniLst(l);
       printf("Numero removido: %d\n",rmv);
    }*/
    FormatoPlha * p1 = criarPilha();
    empilhar(1,p1);
    empilhar(2,p1);
    while(!estaVaziaPilha(p1)){
      printf("Numero desempilhado: %d\n",desempilhar(p1));
   }


    printf("IndFimLst!!!\n");
}
